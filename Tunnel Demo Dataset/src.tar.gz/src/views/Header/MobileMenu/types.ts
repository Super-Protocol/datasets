import { SyntheticEvent } from 'react';

export interface MobileMenuProps {
  onClick: ((event: SyntheticEvent<Element, Event>) => void);
}
