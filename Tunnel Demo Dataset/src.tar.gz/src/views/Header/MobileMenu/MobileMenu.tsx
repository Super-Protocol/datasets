import { useEffect } from 'react';

import { Box, Link } from '@/ui';
import { Logo } from '@/common/components';
import { links } from '@/common/data';
import { MobileMenuProps } from './types';
import classes from './MobileMenu.module.scss';

export const MobileMenu = ({ onClick }: MobileMenuProps) => {
  useEffect(() => {
    document.body.classList.add('disable-scroll');

    return () => {
      document.body.classList.remove('disable-scroll');
    };
  }, []);

  return (
    <Box className={classes.content}>
      <Box className={classes.menu} alignItems="center" justifyContent="space-between">
        <Logo logoType="white" />
        <div className={classes.cross} onClick={onClick} />
      </Box>
      <Box direction="column" className={classes.links} justifyContent="center">
        {links.map(({ id, title, href }) => (
          <Link key={id} href={href} className={classes.link}>{title}</Link>
        ))}
      </Box>
      <Link href="https://superprotocol.typeform.com/testnet">
        <Box className={classes.button} alignItems="center" justifyContent="center">
          Join Testnet
        </Box>
      </Link>
    </Box>
  );
};
