export const copyright = 'Copyright ©2022. SuperProtocol';
