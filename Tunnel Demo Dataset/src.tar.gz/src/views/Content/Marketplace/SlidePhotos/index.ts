export { SlidePhotos } from './SlidePhotos';
