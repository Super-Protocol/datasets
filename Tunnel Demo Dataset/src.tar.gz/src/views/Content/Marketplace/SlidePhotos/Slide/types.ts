export interface SlideProps {
  src: string;
  setSlideWidth: Function;
  setSlideHeight: Function;
  idx: number;
  width: number;
}
