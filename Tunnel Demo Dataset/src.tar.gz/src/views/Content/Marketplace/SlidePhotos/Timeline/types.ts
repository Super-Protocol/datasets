export interface TimelineProps {
  current: number;
  setDirection: (idx: number) => void;
  width: number;
}
