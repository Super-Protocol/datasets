import photo1 from '@/assets/photo1.png';
import photo2 from '@/assets/photo2.png';
import photo3 from '@/assets/photo3.png';

export const INTERVAL_UPDATE = 6000;

export const getPhotos = () => [photo1, photo2, photo3];
