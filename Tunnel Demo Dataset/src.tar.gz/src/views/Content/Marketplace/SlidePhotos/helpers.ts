import photo1 from '@/assets/photo1.jpg';
import photo2 from '@/assets/photo2.jpg';
import photo3 from '@/assets/photo3.jpg';

export const INTERVAL_UPDATE = 6000;

export const getPhotos = () => [photo1, photo2, photo3];
