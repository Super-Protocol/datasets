import { Box, Link } from '@/ui';
import { hrefTwitter } from '@/common/constants';
import twitter from '@/assets/twitter.svg';
import classes from './Share.module.scss';

export const Share = () => (
  <Box className={classes.content} alignItems="center" justifyContent="center">
    <Box>
      <img src={twitter} alt="" />
      <div className={classes.textGroup}>
        <Link href={hrefTwitter}>
          <span className={classes.text}>Share to Twitter</span>
        </Link>
      </div>
    </Box>
  </Box>
);
