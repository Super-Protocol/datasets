export const text = 'This site is hosted on the Super Protocol network';
