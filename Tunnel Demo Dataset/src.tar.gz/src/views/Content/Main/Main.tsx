import { useEffect, useRef } from 'react';
import { text } from './helpers';
import classes from './Main.module.scss';

export const Main = () => {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const handleScroll = () => {
      const element = ref.current;
      if (element) {
        const scrollTop = document.body.scrollTop || document.documentElement.scrollTop || 0;
        element.style.transform = `translate3d(0, -${0.07 * scrollTop}px, 0)`;
      }
    };

    window.addEventListener('scroll', handleScroll);

    return () => {
      window.removeEventListener('scroll', handleScroll);
    };
  }, []);

  return (
    <div className={classes.header}>
      <div className={classes.box}>
        <div className={classes.text}>
          {text}
        </div>
      </div>
      <div className={classes.parallax} ref={ref} />
      <div className={classes.filter} />
    </div>
  );
};
