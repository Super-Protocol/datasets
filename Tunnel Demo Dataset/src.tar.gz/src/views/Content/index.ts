export { Content } from './Content';
