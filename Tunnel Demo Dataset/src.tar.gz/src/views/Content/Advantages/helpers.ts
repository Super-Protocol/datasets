/* eslint-disable max-len */
export const content = [
  {
    title: 'Decentralized',
    text: 'Deploy your applications and websites on multiple servers within the Super Protocol network for increased fault tolerance and resistance to attacks.',
  },
  {
    title: 'Confidential',
    text: 'We believe that decentralized hosting can only be confidential. There is no need to trust the owner of the machine: your code and data are protected by Confidential Computing.',
  },
  {
    title: 'Computing',
    text: 'Super is expanding the capabilities of Web3 by adding a confidential on/off chain computing layer, deeply integrated with blockchains and governed by smart-contracts and dapps.',
  },
];
