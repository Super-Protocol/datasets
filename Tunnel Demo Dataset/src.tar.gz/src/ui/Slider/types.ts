import type { ReactNode } from 'react';

export interface SliderProps {
  data: ReactNode;
  slideWidth: number;
  slideHeight: number;
}
