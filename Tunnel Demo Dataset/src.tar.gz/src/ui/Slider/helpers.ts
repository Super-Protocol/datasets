export const transitionStyle = 'transform 250ms ease-in';
