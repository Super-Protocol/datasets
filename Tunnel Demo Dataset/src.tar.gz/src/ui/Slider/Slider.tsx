import {
  memo, useRef, useEffect, useCallback, useState, useMemo, useImperativeHandle, forwardRef,
} from 'react';

import { Box } from '../Box';
import type { SliderProps } from './types';
import classes from './Slider.module.scss';
import { transitionStyle } from './helpers';

export const Slider = memo(forwardRef<any, SliderProps>(({ data, slideWidth, slideHeight }, ref) => {
  const trackRef = useRef<any>(null);
  const [slide, setSlide] = useState<string>('');

  const initStyles = useCallback(() => {
    const slides: any[] = Array.from(trackRef.current?.children);
    slides.forEach((slide, idx) => {
      slide.style.left = `${slideWidth * (idx - 1)}px`;
    });
  }, [slideWidth]);

  useEffect(() => {
    if (!trackRef) return;
    initStyles();
  }, [initStyles]);

  const initWrapperStyles = useCallback((transform: string, transition?: string) => {
    trackRef.current.style.transform = transform;
    trackRef.current.style.transition = transition || transitionStyle;
  }, []);

  const onClickNext = useCallback(() => {
    initWrapperStyles(`translateX(-${slideWidth}px)`);
    setSlide('next');
  }, [slideWidth, initWrapperStyles]);

  const onClickPrev = useCallback(() => {
    initWrapperStyles(`translateX(${slideWidth}px)`);
    setSlide('prev');
  }, [slideWidth, initWrapperStyles]);

  useImperativeHandle(ref, () => ({
    clickNext() {
      onClickNext();
    },
    clickPrev() {
      onClickPrev();
    },
  }));

  const refresh = useCallback(() => {
    initStyles();
    initWrapperStyles('translateX(0)', 'none');
    setSlide('');
  }, [initStyles, initWrapperStyles]);

  const onTransitionEnd = useCallback((e: any) => {
    if (e.target !== trackRef.current || !slide) return;
    const lastChild = trackRef?.current?.lastChild;
    const firstChild = trackRef?.current?.firstChild;
    if (slide === 'prev') {
      trackRef?.current?.insertBefore(lastChild, firstChild);
    }
    if (slide === 'next') {
      trackRef?.current?.appendChild(firstChild);
    }
    refresh();
  }, [refresh, slide]);

  // const intervalBalanceUpdate = useCallback(() => {
  //   if (interval.current) {
  //     clearInterval(interval.current);
  //   }
  //   interval.current = window.setInterval(() => {
  //     onClickNext();
  //   }, INTERVAL_UPDATE);
  // }, [onClickNext]);

  // useEffect(() => {
  //   intervalBalanceUpdate();
  //   return () => {
  //     if (interval.current) {
  //       clearInterval(interval.current);
  //     }
  //   };
  // }, [intervalBalanceUpdate]);

  const styleTrack = useMemo(() => ({ height: `${slideHeight}px` }), [slideHeight]);
  const styleContainer = useMemo(() => ({ width: `${slideWidth}px` }), [slideWidth]);

  return (
    <Box className={classes.container} justifyContent="center" style={styleContainer}>
      <Box className={classes.track} ref={trackRef} onTransitionEnd={onTransitionEnd} style={styleTrack}>
        {data}
      </Box>
    </Box>
  );
}));
