export const hrefTestNet = 'https://superprotocol.typeform.com/testnet';
export const hrefTwitter = 'https://twitter.com/super__protocol';
