export const links = [
  {
    id: 'whitepaper',
    title: 'Whitepaper',
    href: 'https://docs.superprotocol.com/whitepaper',
  },
  {
    id: 'blog',
    title: 'Blog',
    href: 'https://superprotocol.medium.com',
  },
  {
    id: 'faq',
    title: 'FAQ',
    href: 'https://docs.superprotocol.com/faq',
  },
  {
    id: 'contact-us',
    title: 'Contact Us',
    href: 'https://superprotocol.com/contactus',
  },
];
